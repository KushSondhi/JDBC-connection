package com.jdbc.projects;
public interface Product {

	void ship();
}
