package com.jdbc.projects;

public class Speaker implements Product {

	private String name;
	private double price;

	public Speaker(String name, double price) {
		this.name = name;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public void ship() {
		System.out.println(name + " is shipping");
	}
}
