package com.jdbc.projects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

/**
 * Hello world!
 *
 */
public class App {

	static Connection connection = null;
	static PreparedStatement statement = null;

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");

		connection = DriverManager.getConnection("jdbc:/mysql://localhost:3306/mydb", "username", "password");

		if (!(connection == null)) {
			System.out.println("JDBC Connection Successfully established..");
		} else {
			System.out.println("Failed to make new JDBC Connection");
		}

		Product book = ProductFactory.getProduct("book", "alpha", 15.5);
		addDataToDB("Books", "alpha", 15.5);

		Product speaker = ProductFactory.getProduct("speaker", "marshall", 1999.8);
		addDataToDB("Speakers", "marshall", 1999.8);

		book.ship();
		speaker.ship();

		System.out.println("Getting Data from Books Database...");
		getData("Books");

		System.out.println("Getting Data from Speakers Database...");
		getData("Speaker");
	}

	private static void addDataToDB(String tablename, String bookname, double price) {

		try {

			String insertQueryStatement = "INSERT  INTO " + tablename + " VALUES  (?,?)";
			statement = (PreparedStatement) connection.prepareStatement(insertQueryStatement);

			statement.setString(1, bookname);
			statement.setDouble(2, price);

			statement.executeUpdate();

			System.out.println(tablename + " updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void getData(String tablename) {

		try {
			String getQuery = "SELECT * FROM " + tablename;
			statement = (PreparedStatement) connection.prepareStatement(getQuery);

			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {

				String name = resultSet.getString("Name");
				Double price = resultSet.getDouble("Price");

				System.out.format("%s %f", name, price);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
